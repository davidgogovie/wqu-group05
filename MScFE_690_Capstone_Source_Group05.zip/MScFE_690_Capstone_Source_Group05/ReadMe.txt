EXECUTION INSTRUCTIONS:
1. Copy the entire project folder into the working directory where you have python installed.
2. In Jupiter Notebook, locate and open the program file called main.ipynb
3. Click on the run botton.


NB:Please note that the file main.py is different from main.ipynb
main.ipynb is the one to run which was cloned from main.py